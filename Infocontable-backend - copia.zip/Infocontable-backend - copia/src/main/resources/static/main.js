
$(document).ready(
    function () {
        $(".hoverfontsize").hover(function () {
            console.log("hover event launched")
        })
    }
)



function setFooterContainer() {
    $("#footer_container").html(`  <div class="container">    
    <!-- <div class="border-bottom"></div>  -->
     <footer class="py-1 my-4 ">
         <ul class="nav justify-content-center pb-3 mb-3">
             <li class="nav-item"><a id="textHeaderAndFooter" href="/servicios.html" class="nav-link px-2 text-muted">Servicios </a></li>  
             <li class="nav-item"><a id="textHeaderAndFooter" href="/nosotros.html" class="nav-link px-2 text-muted">Nosotros </a></li>
         </ul>
         
         <p id="textHeaderAndFooter" class=" text-center text-muted">© 2022 Company, Inc</p>
     </footer>
 </div>
    `
    );
}