package com.infocontable.infocontable;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.infocontable.infocontable.model.User;


public class CustomUserDetails implements UserDetails {

    private User user;

    public CustomUserDetails(User user){
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {    
        return null;
    }

    @Override
    public String getPassword() {
        // TODO Auto-generated method stub
        return user.getContrasena();
    }

    @Override
    public String getUsername() {
        // TODO Auto-generated method stub
        return user.getNit();
    }

    @Override
    public boolean isAccountNonExpired() {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isEnabled() {
        // TODO Auto-generated method stub
        return true;
    }

    public String getFullName() {
        return user.getNombre() + " " + user.getApellido();
    }

    public String getIdLogin() {
        return user.getNit();
    }

    


    
}
