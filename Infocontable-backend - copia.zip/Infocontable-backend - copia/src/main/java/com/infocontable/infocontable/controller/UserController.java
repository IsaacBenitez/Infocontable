package com.infocontable.infocontable.controller;

import com.infocontable.infocontable.model.User;
import com.infocontable.infocontable.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
public class UserController {

    @Autowired
    private UserService userService;

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/principal")
    public String viewHomePage(){
        return "menuPrincipalContador";
    }

    @PostMapping("/principal")
    public String viewHomePage2(){
        return "menuPrincipalContador";
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/crearCliente_")
    public String MostrarcrearCliente(User user){
         
        return "crearCliente";
    }

    @PostMapping("/process_register")
    public String processRegistration(User user){
        userService.addUser(user);

        return "redirect:/crearCliente_";
    }

    @GetMapping("consultarListaClientes")
    public String verListaUsuarios(Model model){
        List<User> listUsers = userService.getUsersList(); 
        model.addAttribute("listUsers", listUsers);
        return  "consultarClienteContador";
    }

    @GetMapping("eliminarInfoClientes")  //
    public String verEliminarUsuarios(Model model){
        List<User> listUsers = userService.getUsersList(); 
        model.addAttribute("listUsers", listUsers);
        return  "eliminarClienteContador";
    }


    @GetMapping("process_delete/{nit}")
    private String processDelete(@PathVariable("nit") String nit){
        userService.deleteUser(nit);
        return "redirect:/eliminarInfoClientes";
    }




    @GetMapping("modificarClienteContador")
    private String verUsuarios(Model model){
        model.addAttribute("listUsers", userService.getUsersList());

        return "modificarInfoClienteContador";

    }
   

    @GetMapping("/modificar/{nit}")
    private String verUsuarioPorNit(@PathVariable("nit") String nit, Model model){
        User user = userService.getUser(nit);
        model.addAttribute("user", user);

        return "procesoModificacionContador";
    }
    
    @PostMapping("process_update/{nit}")
    private String processUpdate(@PathVariable("nit") String nit, User user){
        userService.addUser(user);
        return "redirect:/modificarClienteContador";

    }





    

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("listarUsuarios")
    public List<User> listarUsuarios(){
        return userService.getUsersList();
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @GetMapping("buscarUsuario")
    public User buscarUsuario(@RequestParam String nit){return userService.getUser(nit);}

    //@PreAuthorize("hasRole('ADMIN')")
    @PostMapping("crearUsuario")
    public void crearUsuario(@RequestBody User user){
        userService.addUser(user);
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("eliminarUsuario")
    public void eliminarUsuario(@RequestParam String nit){
        userService.deleteUser(nit);
    }

    //@PreAuthorize("hasRole('ADMIN')")
    @PutMapping("editarUsuario")
    public void editarUsuario(@RequestBody User user){
        userService.updateUser(user);
    }

}
